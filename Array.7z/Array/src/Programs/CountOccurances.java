package Programs;

public class CountOccurances {
	
    public static void main(String[] args)
    {
    	String somestring="pranjali";
    	char somechar='r';
    	int count=0;
    	for(int i=0;i<somestring.length();i++) {
    		if(somestring.charAt(1)==somechar) {
    			count++;
    		}
    	}System.out.println(count);
    		}



    }




