package Array1D;

public class PairWithSumInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int[] arr= {-1,2,1,3,5,6,2,0};
   int add=5;
   for(int i=0;i<arr.length;i++) {
	   for(int j=0;j<arr.length;j++) {
		   if(arr[i]+arr[j]==add) {
			   System.out.println(arr[i]+" "+arr[j]);
		   }
	   }
   }
	

}
}