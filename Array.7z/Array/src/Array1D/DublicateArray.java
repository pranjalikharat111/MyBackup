package Array1D;

public class DublicateArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int[] a= {55,55,22,10,46,22,55,88,33,44,44};
 
  for(int i=0;i<a.length;i++) {
	  int count=0;
	 int flag=0;
	 int current=a[i];
	 for(int j=0;j<a.length;j++) {
		 if(current==a[j]) {
			 count++;
			 flag=1;
		 }
	 }
	 if(flag==1 && count>=2) 
			 System.out.println("dublicate element"+current+ "and count is" +count);
		 
	 }
	 
  }
  
	}


