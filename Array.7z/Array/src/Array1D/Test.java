package Array1D;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		for (i=0;i<10;i++) {
			System.out.println( i);
			
			if (i==4) {
			continue;}
	}
			
	}

}
